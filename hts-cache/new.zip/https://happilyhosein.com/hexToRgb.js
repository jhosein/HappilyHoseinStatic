<!doctype html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge, IE=11, IE=10">
<link rel="pingback" href="https://happilyhosein.com/xmlrpc.php" />
<title>Page not found - Happily Hosein</title>

<meta name="robots" content="noindex,follow" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - Happily Hosein" />
<meta property="og:site_name" content="Happily Hosein" />
<meta property="og:image" content="https://happilyhosein.com/wp-content/uploads/2019/10/IMG_6608_Fotor-1024x683.jpg" />
<meta property="og:image:secure_url" content="https://happilyhosein.com/wp-content/uploads/2019/10/IMG_6608_Fotor-1024x683.jpg" />
<meta property="og:image:width" content="1024" />
<meta property="og:image:height" content="683" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found - Happily Hosein" />
<meta name="twitter:image" content="https://happilyhosein.com/wp-content/uploads/2019/10/IMG_6608_Fotor.jpg" />
<script type='application/ld+json' class='yoast-schema-graph yoast-schema-graph--main'>{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://happilyhosein.com/#website","url":"https://happilyhosein.com/","name":"Happily Hosein","publisher":{"@id":"https://happilyhosein.com/#/schema/person/"},"potentialAction":{"@type":"SearchAction","target":"https://happilyhosein.com/?s={search_term_string}","query-input":"required name=search_term_string"}}]}</script>

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Happily Hosein &raquo; Feed" href="https://happilyhosein.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Happily Hosein &raquo; Comments Feed" href="https://happilyhosein.com/comments/feed/" />
<script type="effa370e77a9e42c69c9d9b5-text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/happilyhosein.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.7"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://happilyhosein.com/wp-includes/css/dist/block-library/style.min.css?ver=5.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://happilyhosein.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='stack-style-css' href='https://happilyhosein.com/wp-content/themes/stack/style.css?ver=5.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='stack-child-style-css' href='https://happilyhosein.com/wp-content/themes/stack-child/style.css?ver=10.5.17' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-css'  href='https://happilyhosein.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.3' type='text/css' media='screen' />
<![endif]-->
<link rel='stylesheet' id='ebor-google-font-css' href='//fonts.googleapis.com/css?family=Open+Sans%3A200%2C300%2C400%2C400i%2C500%2C600%2C700%7CMerriweather%3A300%2C300i%7CMaterial+Icons&#038;ver=10.5.17' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://happilyhosein.com/wp-content/themes/stack/style/css/bootstrap.css?ver=10.5.17' type='text/css' media='all' />
<link rel='stylesheet' id='ebor-icons-css' href='https://happilyhosein.com/wp-content/themes/stack/style/css/icons.css?ver=10.5.17' type='text/css' media='all' />
<link rel='stylesheet' id='ebor-plugins-css' href='https://happilyhosein.com/wp-content/themes/stack/style/css/plugins.css?ver=10.5.17' type='text/css' media='all' />
<link rel='stylesheet' id='ebor-theme-css' href='https://happilyhosein.com/wp-content/uploads/wp-less/stack/style/css/theme-3184233f84.css' type='text/css' media='all' />
<link rel='stylesheet' id='ebor-style-css' href='https://happilyhosein.com/wp-content/themes/stack-child/style.css?ver=10.5.17' type='text/css' media='all' />
<style id='ebor-style-inline-css' type='text/css'>

			.btn--primary .btn__text, .btn--primary:visited .btn__text {
			    color: #ffffff;	
			}
			input[type].btn--primary,
			.pos-fixed.bar--transparent.bg--primary,
			.ebor-cart-count, .woocommerce #respond input#submit.alt.disabled, .woocommerce #respond input#submit.alt.disabled:hover, .woocommerce #respond input#submit.alt:disabled, .woocommerce #respond input#submit.alt:disabled:hover, .woocommerce #respond input#submit.alt:disabled[disabled], .woocommerce #respond input#submit.alt:disabled[disabled]:hover, .woocommerce a.button.alt.disabled, .woocommerce a.button.alt.disabled:hover, .woocommerce a.button.alt:disabled, .woocommerce a.button.alt:disabled:hover, .woocommerce a.button.alt:disabled[disabled], .woocommerce a.button.alt:disabled[disabled]:hover, .woocommerce button.button.alt.disabled, .woocommerce button.button.alt.disabled:hover, .woocommerce button.button.alt:disabled, .woocommerce button.button.alt:disabled:hover, .woocommerce button.button.alt:disabled[disabled], .woocommerce button.button.alt:disabled[disabled]:hover, .woocommerce input.button.alt.disabled, .woocommerce input.button.alt.disabled:hover, .woocommerce input.button.alt:disabled, .woocommerce input.button.alt:disabled:hover, .woocommerce input.button.alt:disabled[disabled], .woocommerce input.button.alt:disabled[disabled]:hover {
				background: #4A90E2;	
			}
			.pos-fixed.bar--transparent.bg--secondary {
				background: #FAFAFA;
			}
			.pos-fixed.bar--transparent.bg--dark {
				background: #252525;
			}
			.pos-fixed.bar--transparent.bg--primary-1 {
				background: #31639C;
			}
			.bg--white h1, .bg--white h2, .bg--white h3, .bg--white h4, .bg--white h5, .bg--white h6, .bg--white i, .mobile-header .cart-link {
			    color: #252525;
			}
			@media all and (max-width:767px) {
			    .bar.bg--dark.bar--mobile-sticky[data-scroll-class*="fixed"].pos-fixed,
			    .bar.bg--dark.bar--mobile-sticky[data-scroll-class*="fixed"]+.bar.pos-fixed {
			    	background: #252525;
			    }
			    .bar.bg--secondary.bar--mobile-sticky[data-scroll-class*="fixed"].pos-fixed,
			    .bar.bg--secondary.bar--mobile-sticky[data-scroll-class*="fixed"]+.bar.pos-fixed {
			    	background: #FAFAFA;
			    }
			}
			.thumbnails-slider .thumbnail-trigger.active img {
				border: 1px solid #4A90E2;
			}
			.menu-horizontal > li > a, .menu-horizontal > li > span, .menu-horizontal > li > .modal-instance > .modal-trigger {
				font-size: 1em;
			}
			.woocommerce #respond input#submit.alt, 
			.woocommerce a.button.alt, 
			.woocommerce button.button.alt, 
			.woocommerce input.button.alt,
			.woocommerce #respond input#submit, 
			.woocommerce a.button, 
			.woocommerce button.button, 
			.woocommerce input.button {
				background: #4A90E2;
				color: #fff;
				transition: 0.1s linear;
			}
			.woocommerce #respond input#submit.alt:hover, 
			.woocommerce a.button.alt:hover, 
			.woocommerce button.button.alt:hover, 
			.woocommerce input.button.alt:hover,
			.woocommerce #respond input#submit:hover, 
			.woocommerce a.button:hover, 
			.woocommerce button.button:hover, 
			.woocommerce input.button:hover {
				color: #fff;
				opacity: 0.9;
				background: #4A90E2;
				transform: translate3d(0, -2px, 0);
				-webkit-transform: translate3d(0, -2px, 0);
			}
		
				.col-md-11.col-sm-12.text-right.text-left-xs.text-left-sm {
					margin-top: 5px;	
				}
			
</style>
<link rel='stylesheet' id='ebor-iconsmind-css' href='https://happilyhosein.com/wp-content/themes/stack/style/css/iconsmind.css?ver=10.5.17' type='text/css' media='all' />
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='https://happilyhosein.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://happilyhosein.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://happilyhosein.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.2.7" />
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
<link rel="icon" href="https://happilyhosein.com/wp-content/uploads/2019/11/cropped-favicon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://happilyhosein.com/wp-content/uploads/2019/11/cropped-favicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://happilyhosein.com/wp-content/uploads/2019/11/cropped-favicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://happilyhosein.com/wp-content/uploads/2019/11/cropped-favicon-270x270.png" />
<style type="text/css" id="wp-custom-css">
			@import url('https://fonts.googleapis.com/css?family=Playfair+Display&display=swap');
		</style>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 stack--rounded normal-layout active-tabs active-accordions parallax-enable-mobile wpb-js-composer js-comp-ver-6.0.3 vc_responsive" data-smooth-scroll-offset="0" data-smooth-scroll-offset-mobile="0" data-skip-responsive-menu="no">
<a href="#" id="start" title="Start"></a>
<div class="main-container">
<section class="height-100 bg--dark text-center">
<div class="container pos-vertical-center">
<div class="row">
<div class="col-sm-12">
<h1 class="h1--large">404</h1>
<p class="lead">The page you were looking for doesn&#039;t appear to exist.</p>
<a href="https://happilyhosein.com/">Go back to home page</a>
</div>
</div>
</div>
</section>
<footer class="footer-3 text-center-xs space--xs">
<div class="container">
<div class="row">
<div class="col-sm-6">
<a href="https://happilyhosein.com/" class="footer-logo-holder logo-holder">
<img class="logo logo-dark" alt="Happily Hosein" src="https://happilyhosein.com/wp-content/uploads/2019/10/LogoMakr_1VVvhM.png" />
<img class="logo logo-light" alt="Happily Hosein" src="https://happilyhosein.com/wp-content/uploads/2019/10/LogoMakr_4XvJ1x.png" />
</a> </div>
<div class="col-sm-6 text-right text-center-xs">
<ul class="social-list list-inline list--hover stack-footer-social">
</ul> </div>
</div>
<div class="row">
<div class="col-sm-6">
<p class="type--fine-print">Join Savannah Stokes and Jonathan Hosein on their happily ever after</p>
</div>
<div class="col-sm-6 text-right text-center-xs">
<div class="footer-stack-copyright">
<span class="type--fine-print"><a href="http://www.tommusrhodus.com">Stack Premium WordPress Theme by TommusRhodus</a></span></div> </div>
</div>
</div>
</footer>
</div>
<a class="back-to-top inner-link" title="Back to top" href="#start" data-scroll-class="100vh:active">
<i class="stack-interface stack-up-open-big"></i>
</a><script type="effa370e77a9e42c69c9d9b5-text/javascript">
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/happilyhosein.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.4'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/parallax.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/isotope.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/final-countdown.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/flickity.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/granim.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/smooth-scroll.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/spectragram.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/twitter-post-fetcher.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/ytplayer.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/easy-pie-chart.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/steps.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/lightbox.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript">
/* <![CDATA[ */
var stack_data = {"access_token":"replaceWithYourOwn","client_id":"replaceWithYourOwn","typed_speed":"100","map_marker":"https:\/\/happilyhosein.com\/wp-content\/themes\/stack\/style\/img\/mapmarker.png","map_marker_title":"Stack","lightbox_text":"Image %1 of %2"};
/* ]]> */
</script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/scripts_wp.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-content/themes/stack/style/js/scripts.js?ver=10.5.17'></script>
<script type="effa370e77a9e42c69c9d9b5-text/javascript" src='https://happilyhosein.com/wp-includes/js/wp-embed.min.js?ver=5.2.7'></script>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="effa370e77a9e42c69c9d9b5-|49" defer=""></script></body>
</html>
